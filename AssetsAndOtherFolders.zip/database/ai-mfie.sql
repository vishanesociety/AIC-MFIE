-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2021 at 02:37 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ai-mfie`
--

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `Username` varchar(200) NOT NULL,
  `company_name` char(200) NOT NULL,
  `company_url` varchar(200) NOT NULL,
  `company_demo` varchar(200) NOT NULL,
  `company_description` varchar(400) NOT NULL,
  `company_products` varchar(500) NOT NULL,
  `company_currentlocation` varchar(200) NOT NULL,
  `contact_email` varchar(100) NOT NULL,
  `contact_phone` varchar(200) NOT NULL,
  `founders_url` varchar(200) NOT NULL,
  `founders_count` varchar(200) NOT NULL,
  `category_type` varchar(100) NOT NULL,
  `progress_faralong` varchar(600) NOT NULL,
  `progress_working` varchar(600) NOT NULL,
  `progress_usingproduc` varchar(50) NOT NULL,
  `progress_revenue` varchar(50) NOT NULL,
  `progress_change` varchar(600) NOT NULL,
  `progress_committed` varchar(600) NOT NULL,
  `idea_domainexpert` varchar(600) NOT NULL,
  `idea_new` varchar(600) NOT NULL,
  `idea_competitors` varchar(600) NOT NULL,
  `idea_understanding` varchar(600) NOT NULL,
  `idea_makemoney` varchar(600) NOT NULL,
  `idea_users` varchar(600) NOT NULL,
  `equity_legalentity` varchar(50) NOT NULL,
  `equity_investment` varchar(50) NOT NULL,
  `equity_plan` varchar(600) NOT NULL,
  `equity_structure` varchar(600) NOT NULL,
  `legal_overlap` varchar(600) NOT NULL,
  `legal_codes` varchar(600) NOT NULL,
  `legal_knowledge` varchar(600) NOT NULL,
  `others_ideas` varchar(600) NOT NULL,
  `others_surprising` varchar(600) NOT NULL,
  `curious_apply` varchar(600) NOT NULL,
  `curious_hear` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`Username`, `company_name`, `company_url`, `company_demo`, `company_description`, `company_products`, `company_currentlocation`, `contact_email`, `contact_phone`, `founders_url`, `founders_count`, `category_type`, `progress_faralong`, `progress_working`, `progress_usingproduc`, `progress_revenue`, `progress_change`, `progress_committed`, `idea_domainexpert`, `idea_new`, `idea_competitors`, `idea_understanding`, `idea_makemoney`, `idea_users`, `equity_legalentity`, `equity_investment`, `equity_plan`, `equity_structure`, `legal_overlap`, `legal_codes`, `legal_knowledge`, `others_ideas`, `others_surprising`, `curious_apply`, `curious_hear`) VALUES
('kshitijsingh10762', '', '', '', '', '', '', '', '', '', '$founders_count', '<?php$category_type;?>', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
('me.kshitijsingh', 'werewrwerewrew', 'werewrwerewrew', 'werewrwerewrew', 'werewrwerewrew', 'ewfewfwe', 'wefewfwe', 'wefwef', 'wefwefwewefewf', 'wefewf', '3', 'Augmented Reality', 'wefewf', 'wfefew', 'Yes', 'Yes', 'weffewf', 'wefwefwef', 'wefwefewfw', 'ewfwefewf', 'wefewfwef', 'wefwefewfew', 'fewfewfwef', 'wefwefw', 'No', 'No', 'wefewf', 'wefwefew', 'wefwefew', 'wefwefewfew', 'wefewfwe', 'fwefewfewf', 'wefwefwef', 'wefewfewf', 'wefewfew');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `Username` varchar(200) NOT NULL,
  `password` varchar(300) NOT NULL,
  `token` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`fname`, `lname`, `email`, `Username`, `password`, `token`) VALUES
('kenway', 'ac', 'kenway.ac1721@gmail.com', 'kenway.ac1721', '4f4c857df5fdf25c62447bd2ccc4e76e', '2b6f993c1bdc6468ce2b6bb3ec76cf'),
('kshitij', 'singh', 'kshitijsingh10762@gmail.com', 'kshitijsingh10762', '4f4c857df5fdf25c62447bd2ccc4e76e', 'b8b2a7333dd733c5b081ad01553ace'),
('kshitij', 'singh', 'me.kshitijsingh@gmail.com', 'me.kshitijsingh', '4f4c857df5fdf25c62447bd2ccc4e76e', 'fa270a56d2cb744efa7102c47ac2b9');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
